<!DOCTYPE HTML>  
<html>
<head>
  <title> forgot password </title>


</head>
<body>  
  <div class="header">
    <h2>Forgot Password</h2>
  </div>


<form method="post" action="forgot password.php"
  <div class="input-group">
    <label>Enter Email</label>
    <input type="text" name="enter email">
  </div><br><br>
  
  
  
  <input type="submit" name="submit" value="Submit">  
</form><br>

</form>






</body>
</html>