<!DOCTYPE HTML>  
<html>
<head>
  <title> registration </title>


</head>
<body>  
  <div class="header">
    <h2>Registraion Form</h2>
  </div>


<form method="post" action="2.php"
  <div class="input-group">
    <label>Username</label>
    <input type="text" name="username">
  </div><br><br>
  <div class="input-group">
    <label>Email</label>
    <input type="text" name="username">
  </div><br><br>
  <div class="input-group">
    <label>Username</label>
    <input type="text" name="username">
  </div><br><br>
  <div class="input-group">
    <label>Password</label>
    <input type="text" name="username">
  </div><br><br>
  <div class="input-group">
    <label>Confirm Password</label>
    <input type="text" name="username">
  </div><br><br>
  Gender:
  <input type="radio" name="gender" value="female">Female
  <input type="radio" name="gender" value="male">Male
  <input type="radio" name="gender" value="other">Other
  <br><br><br><br>
<div class="input-group">
    <label>Date Of Birth</label>
    <input type="text" name="username">
  </div>
  <br><br>
  <input type="submit" name="submit" value="Submit">  
</form><br>
<input type="reset" name="reset" value="Reset">  
</form>






</body>
</html>