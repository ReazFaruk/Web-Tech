<!DOCTYPE HTML>  
<html>
<head>
  <title> login </title>


</head>
<body>  
  <div class="header">
    <h2>Login Form</h2>
  </div>


<form method="post" action="login.php"
  <div class="input-group">
    <label>Username</label>
    <input type="text" name="username">
  </div><br><br>
  
  
  <div class="input-group">
    <label>Password</label>
    <input type="text" name="username">
  </div><br><br>
  
  Remember me:
  <input type="radio" name="Remember me" value=""><br><br>
  

  <input type="submit" name="submit" value="Submit">  
</form><br>

</form>






</body>
</html>